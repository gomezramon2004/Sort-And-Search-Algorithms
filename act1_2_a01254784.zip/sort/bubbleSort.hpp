#pragma once
#include <vector>

int ordenaBurbuja(std::vector<int>& vec);