#pragma once
#include <vector>

int ordenaIntercambio(std::vector<int>& vec);