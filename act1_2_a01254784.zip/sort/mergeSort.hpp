#pragma once
#include <vector>

int merge(std::vector<int>& vec, int left, int mid, int right, int& count);
int ordenaMerge(std::vector<int>& vec, int left, int right, int& count);