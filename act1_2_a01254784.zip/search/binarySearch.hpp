#pragma once
#include <vector>

struct Values { int index, count; };
Values busqBinaria(const std::vector<int>& vec, int target);