#pragma once
#include <vector>

int busqSecuencial(const std::vector<int>& vec, int target);